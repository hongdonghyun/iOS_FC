//
//  AppDelegate.swift
//  Counter
//
//  Created by Giftbot on 2019/11/25.
//  Copyright © 2019 Giftbot. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

}
