//
//  UserModels.swift
//  LoginPageExample
//
//  Created by Hongdonghyun on 2019/12/14.
//  Copyright © 2019 hong3. All rights reserved.
//

import Foundation

let ID = "hong3"
let PWD = "123456"
