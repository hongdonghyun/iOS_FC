//
//  WishListController.swift
//  DominoExample
//
//  Created by cskim on 2019/12/26.
//  Copyright © 2019 cskim. All rights reserved.
//

import UIKit

class WishListController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }

    private func setupUI() {
        
    }

}
