//
//  OrderViewController.swift
//  DominoExample
//
//  Created by cskim on 2019/12/26.
//  Copyright © 2019 cskim. All rights reserved.
//

import UIKit

class OrderViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    
    // MARK: TableView Data
    
    let datas: [DominoMenu] = [
        DominoMenu(category: "슈퍼시드 함유 도우",
                   menus: [
                    Menu(name: "글램핑 바비큐", price: 35_900, thumbnail: DominoImage.hotPizza),
                    Menu(name: "알로하 하와이안", price: 31_900, thumbnail: DominoImage.whitePizza),
                    Menu(name: "우리 고구마", price: 31_900, thumbnail: DominoImage.shrimpPizza),
                    Menu(name: "콰트로 치즈 퐁듀", price: 25_900, thumbnail: DominoImage.meatPizza),
        ]),
        DominoMenu(category: "프리미엄", menus: []),
        DominoMenu(category: "클래식", menus: []),
        DominoMenu(category: "사이드디스", menus: []),
        DominoMenu(category: "음료", menus: []),
    ]
    
    let imageView = UIImageView()
    let tableView = UITableView()
    private func setupUI() {
        self.view.backgroundColor = .white
        
        self.navigationItem.title = "Domino's"
        
        imageView.image = UIImage(named: DominoImage.logo)
        imageView.contentMode = .scaleAspectFit
        self.view.addSubview(imageView)
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "CategoryCell")
        self.view.addSubview(tableView)
        
        setupConstraint()
    }
    
    private func setupConstraint() {
        let guide = self.view.safeAreaLayoutGuide
        imageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: guide.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            imageView.heightAnchor.constraint(equalToConstant: 200),
        ])
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: imageView.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: guide.bottomAnchor),
        ])
    }
    
}

// MARK:- UITableViewDataSource

extension OrderViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryCell", for: indexPath)
        let data = datas[indexPath.row]
        cell.textLabel?.text = data.category
//        cell.contentView.backgroundColor = UIColor(patternImage: UIImage(named: DominoImage.logo)!)
        return cell
    }
}

// MARK:- UITableViewDelegate

extension OrderViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let menuListVC = MenuListController()
        menuListVC.menuInfo = datas[indexPath.row]
//        menuListVC.menuTitle = datas[indexPath.row]
        self.navigationController?.pushViewController(menuListVC, animated: true)
    }
}
