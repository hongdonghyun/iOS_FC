//
//  ImageAnimationViewController.swift
//  UIViewAnimation
//
//  Created by giftbot on 2020. 1. 7..
//  Copyright © 2020년 giftbot. All rights reserved.
//

import UIKit

final class ImageAnimationViewController: UIViewController {
  
  @IBOutlet private weak var imageView: UIImageView!
  @IBOutlet private weak var durationLabel: UILabel!
  @IBOutlet private weak var repeatCountLabel: UILabel!
  
  let images = [
    "AppStore", "Calculator", "Calendar", "Camera", "Clock", "Contacts", "Files"
  ]
  
  override func viewDidLoad() {
    super.viewDidLoad()
  }
  
  @IBAction private func startAnimation(_ sender: Any) {
  }
  
  @IBAction private func stopAnimation(_ sender: Any) {
  }
  
  @IBAction private func durationStepper(_ sender: UIStepper) {
  }
  
  @IBAction private func repeatCountStepper(_ sender: UIStepper) {
  }
}
