/*:
 # ARC (Automatic Reference Counting)
 
 1. **ARC Basic**
 2. **Scope**
 3. **Strong Reference Cycles**
 4. **Strong, Unowned, Weak**
 5. **Practice**
 
 by Giftbot
*/
//: [Next](@next)
