/*:
 # Type Casting
 
 * Type Check
 * Type Casting
 
 by Giftbot
*/
//: [Next](@next)
