/*:
 # Singleton
 
 * Singleton
 * Practice
 * Singleton Example
 
 by Giftbot
 */

//: [Next](@next)
