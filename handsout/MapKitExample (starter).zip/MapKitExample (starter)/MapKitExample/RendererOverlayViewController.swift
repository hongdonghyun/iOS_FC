//
//  RendererOverlayViewController.swift
//  MapKitExample
//
//  Created by giftbot on 2020. 1. 5..
//  Copyright © 2020년 giftbot. All rights reserved.
//

import MapKit
import UIKit

final class RendererOverlayViewController: UIViewController {
  
  @IBOutlet private weak var mapView: MKMapView!
  
  @IBAction func addCircle(_ sender: Any) {
  }
  
  @IBAction func addStar(_ sender: Any) {
  }
  
  @IBAction private func removeOverlays(_ sender: Any) {
  }
}
