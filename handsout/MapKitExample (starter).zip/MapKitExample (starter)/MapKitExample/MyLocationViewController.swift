//
//  MyLocationViewController.swift
//  MapKitExample
//
//  Created by giftbot on 2020. 1. 5..
//  Copyright © 2020년 giftbot. All rights reserved.
//

import MapKit
import UIKit

final class MyLocationViewController: UIViewController {
  
  @IBOutlet private weak var mapView: MKMapView!
  let locationManager = CLLocationManager()
  
  override func viewDidLoad() {
    super.viewDidLoad()
  }
  
  
  func checkAuthorizationStatus() {
  }
  
  func startUpdatingLocation() {
  }
  
  @IBAction func mornitoringHeading(_ sender: Any) {
  }
  
  @IBAction func stopMornitoring(_ sender: Any) {
  }
}

