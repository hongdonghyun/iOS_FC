//
//  models.swift
//  DogBirdCat
//
//  Created by Hongdonghyun on 2019/12/04.
//  Copyright © 2019 hong3. All rights reserved.
//

import Foundation

enum Animal: String{
    case Dog
    case Cat
    case Bird
}
